# Integrantes del equipo:
#Angel Esau Hernandez Garcia
#Hugo Gael Arredondo Esparza
#Kevin Rafael Ochoa López
from distutils.core import setup
import py2exe

setup(
    console=['execute_pyautogui.py'],
)
